/****************************************************************************
    Description:	Implements the CHopper control class.
    Classes:		CHopper
    Project:		2020 Infinite Recharge Robot Code.
    Copyright 2020 First Team 3284 - Camdenton LASER Robotics.
****************************************************************************/
#include "Hopper.h"

using namespace frc;
using namespace rev;
/////////////////////////////////////////////////////////////////////////////


/****************************************************************************
    Description:	CHopper Constructor.
    Arguments:		None
    Derived From:	Nothing
****************************************************************************/
CHopper::CHopper()
{
    // Create Object Pointers.
    m_pShooterFeeder	= new CANSparkMax(nPreloadMotor, CANSparkMax::MotorType::kBrushless);
}

/****************************************************************************
    Description:	CHopper Destructor.
    Arguments:		None
    Derived From:	Nothing
****************************************************************************/
CHopper::~CHopper()
{
    // Delete objects.
    delete m_pShooterFeeder;

    // Set objects to nullptrs.
    m_pShooterFeeder	= nullptr;
}

/****************************************************************************
    Description:	Initialize Hopper parameters.
    Arguments: 		None
    Returns: 		Nothing
****************************************************************************/
void CHopper::Init()
{
    // Turn off shooter preload.
    m_pShooterFeeder->Set(0.00);
}

/****************************************************************************
    Description:	Start feeding Energy through the hopper.
    Arugments: 		bool - True for start, false for stop.
    Returns: 		Nothing
****************************************************************************/
void CHopper::Preload(bool bEnabled)
{
    if (bEnabled)
    {
        // Start preloading into the shooter.
        m_pShooterFeeder->Set(dHopperPreloadSpeed);
    }
    else
    {
        // Stop the preloader.
        m_pShooterFeeder->Set(0.00);
    }
}
/////////////////////////////////////////////////////////////////////////////
